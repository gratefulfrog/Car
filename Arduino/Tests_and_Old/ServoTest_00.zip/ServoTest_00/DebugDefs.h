#ifndef DEBUGDEFS_H
#define DEBUGDEFS_H

//#define DEBUG

#endif
