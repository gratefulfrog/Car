# RemoteObserver
Rotate and zoom a cube on your PC using your Android phone. The sensor data is sent over OSC.

The Ketai library (http://ketai.org/) is used to capture the sensor data and the oscP5 library (http://www.sojamo.de/libraries/oscP5/) is used to stream the data from the android application to the application that runs on your PC.
To establish the connection, the user must input on their android phone the private IP of the PC they are targeting.

Read more on my blog (http://psybercity.co.uk/2015/08/19/remoteobserver_android-app/) about methodology.
Extensive comments in the code as well.
